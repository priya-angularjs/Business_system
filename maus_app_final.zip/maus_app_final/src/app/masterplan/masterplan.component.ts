import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-masterplan',
  templateUrl: './masterplan.component.html',
  styleUrls: ['./masterplan.component.scss']
})
export class MasterplanComponent implements OnInit {
  links = ['Overview', 'Products', 'Markets', 'Competitors', 'SWOT','Objectives',
    'Marketing', 'Operational', 'Financial','Milestones','Report'];
  activeLink = this.links[0];
  background = 'primary';
  value;
  constructor() { }

  ngOnInit() {
    this.value = 1;
  }

}
