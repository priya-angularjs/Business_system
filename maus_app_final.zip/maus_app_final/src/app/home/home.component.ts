import { Component, OnInit } from '@angular/core';
import {MenuItem} from 'primeng/api';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

  items: MenuItem[];

  constructor() { }

  ngOnInit() {
    this.items = [
      {
        label: 'Strategy & Financial',
        icon: 'pi pi-fw pi-dollar'
      },
      {
        label: 'Human Resources',
        icon: 'pi pi-fw pi-user'
      },
      {
        label: 'Health & Safety',
        icon: ' pi pi-fw pi-plus'
      },
      {
        label: 'Documents & Policies',
        icon: 'pi pi-fw pi-file'
      },
      {
        label: 'Assessment & Diagnostics',
        icon: 'pi pi-fw pi-images'
      },
      {
        label: 'Master Plan Lean',
        routerLink: 'masterplan',
        icon: 'pi pi-fw pi-calendar',
      },
      {
        label: 'Support',
        icon: 'pi pi-fw pi-share-alt'
      },
    ];
  }
}
